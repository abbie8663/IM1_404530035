
public class Easter {
	public String calculateEaster(int aYear) {
		int a = aYear % 19;
		int b = aYear % 4;
		int c = aYear % 7;
		int k = (aYear / 100);
		int p = ((13 + 8 * k) / 25);
		int q = (k / 4);
		int M = (15 - p + k - q) % 30;
		int N = (4 + k - q) % 7;
		int d = (19 *a +M) % 30;
		int e = (2 * b + 4 * c + 6 * d + N) % 7;

		if (d + e<10)
		
		{
			int day=22+d+e;
			
			return "In" + aYear + "Easter Sunday is: month = 3 and day =" + day;
		}

		else  {
			int day2=d+e-9;
			
			return "In" + aYear + "Easter Sunday is: month = 4 and day =" + day2;
		}
		

	}
	
	
	
	
	
}