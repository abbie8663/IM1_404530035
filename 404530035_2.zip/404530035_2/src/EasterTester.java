import java.util.Scanner;

public class EasterTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Easter easter=new Easter();
		
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Your Year:");
		int aYear1 =scanner.nextInt();
		System.out.println(easter.calculateEaster(aYear1));
		
		
		System.out.println("Your Year:");
		int aYear2 =scanner.nextInt();
		System.out.println( easter.calculateEaster(aYear2));
		

	}

}
