package bank;

import java.util.ArrayList;

public class BankAccount {
	String state;
	int accountNumber;
	private double balance;
	private ArrayList<Double> TransactionList=null;

	
	public BankAccount(){
		this(-1,-1);
		
	}

	public BankAccount(int anAccountNumber){
		this(anAccountNumber,0);
		
	}	
	

	public BankAccount(int anAccountNumber, double initialBalance ) {
		this.state = "open";
		this.accountNumber = anAccountNumber;
		this.balance = initialBalance;
		this.TransactionList =new ArrayList<Double>();	
		
		
	}
	
	
	 boolean isOpen(){
		if (this.state.equals("open"))
		return true;
		else{
			return false;
			
		}
	}
	 boolean isSuspend(){
			if (this.state.equals("suspend"))
			return true;
			else{
				return false;
				
			}
		}
	
	 boolean isClosed(){
			if (this.state.equals("closed"))
			return true;
			else{
				return false;
				
			}
		}
	 
	 
	void reOpen(){
		this.state="open";
	}
	
	void suspend(){
		this.state="suspend";
	}
	
	
	void closed(){
		this.state="closed";
	}
	
	void deposit(double amount)throws Exception{
		if (!this.isOpen() && amount >0){
			throw new Exception ("transaction:"+this.accountNumber+"deposit occur");
			
		}
		this.balance += amount;
		addTransaction(amount); 
		
	}
	
	
	
	
	void withdraw (double amount)throws Exception{
		if (!this.isOpen() && amount >0 && this.balance<=amount){
			throw new Exception ("transaction:"+this.accountNumber+"withdraw occur");
			
		}
		this.balance -= amount;
		addTransaction(0-amount);
		
	}
	
	private void addTransaction(double amount){
		this.TransactionList.add(amount);
		
	}
	
	String getTransations(){
		StringBuffer sb =new StringBuffer();
		for (int i = 0; i < this.TransactionList.size();i++ )
		{  sb.append((i+1)+":"+this.TransactionList.get(i)+"\n");
		}
		return sb.toString();
	}
	
	int retrieveNumberOfTransactions(){
		return this.TransactionList.size();
		
	}
	
	public double getBalance(){
		return 0;
		
	}
	
}
