package bank;
import java.util.ArrayList;
import java.util.HashMap;

public class Bank {

	HashMap<Integer,BankAccount> BankList = new HashMap<Integer,BankAccount>();
	private ArrayList<BankAccount> accounts;
	public Bank()
	{
		accounts = new ArrayList<BankAccount>();
		
	}
	public void addAccount(int accountNumber, int initialBalance) {
		// TODO Auto-generated method stub
		if(initialBalance < 0)
			initialBalance = 0;
		
		BankList.put(accountNumber, new BankAccount(accountNumber,initialBalance));
	}

	public void deposit(int accountNumber, int initialBalance) {
		// TODO Auto-generated method stub
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.deposit(initialBalance);
			
		}catch (Exception e ){
			
			System.out.println(e.getMessage());
		}
		
		
	}

	public void withdraw(int accountNumber, int initialBalance) {
		// TODO Auto-generated method stub
		BankAccount tempAccount= (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.deposit(initialBalance);
			
		}catch (Exception e ){
			
			System.out.println(e.getMessage());
		}
	}

	public void closeAccount(int accountNumber) {
		// TODO Auto-generated method stub
		BankAccount tempAccount = (BankAccount)BankList.get(accountNumber);
		tempAccount.closed();
	}

	public void suspendAccount(int accountNumber) {
		// TODO Auto-generated method stub
		BankAccount tempAccount =(BankAccount)BankList.get(accountNumber);
		tempAccount.suspend();
	}

	public void reOpenAccount(int accountNumber) {
		// TODO Auto-generated method stub
		BankAccount tempAccount =(BankAccount)BankList.get(accountNumber);
		tempAccount.reOpen();
		
		
	}
	
	public double getBalance (int accountNumber){
		BankAccount tempAccount = (BankAccount)BankList.get(accountNumber);
		return tempAccount.getBalance();
	}

	public String getAccountTransaction(int accountNumber){
		BankAccount tempAccount = (BankAccount)BankList.get(accountNumber);
		return tempAccount.state;
		
	}
	
	public String summarizeAccountTransactions(int accountNumber){
		
		StringBuffer sb=new StringBuffer();
		BankAccount tempAccount =(BankAccount)BankList.get(accountNumber);
		sb.append("Account #"+accountNumber+"transactions:\n\n");
		sb.append(tempAccount.getTransations());
		sb.append("End of transactions\n");
	
		return sb.toString();
	}
	
	public String summarizeAllAccount(){
	StringBuffer sb = new StringBuffer();
	sb.append("Acoount\tBalance\t#Transactions\tStatus\n");
	for (BankAccount bank : BankList.values()){
		sb.append(bank.accountNumber+"\t");
		sb.append(bank.getBalance()+"\t");
		sb.append(bank.retrieveNumberOfTransactions()+"\t\t");
		sb.append(bank.state+"\n");
	}
		sb.append("End of Account Summary\n");
		return sb.toString();
	}
		
	}
	
	
	
	
	
	
	